import Loginimage from "./Loginimage"
import Loginleft from "./Loginleft"


const Sigin = () => {
  return (

<section className= " border-red-500 bg-gray-200 py-20 flex items-center justify-center">
  <div className="bg-gray-100 p-5 flex rounded-2xl shadow-lg max-w-3xl">
   <Loginleft />
   <Loginimage />
  </div>
</section>



  )
}

export default Sigin
