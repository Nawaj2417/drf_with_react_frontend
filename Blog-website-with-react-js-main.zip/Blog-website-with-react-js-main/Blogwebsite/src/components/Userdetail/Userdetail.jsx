import React from 'react'

const Userdetail = () => {
  return (
    <div>
      <h1>hello userdetail page</h1>
    </div>
  )
}

export default Userdetail
